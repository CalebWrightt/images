"""Repack editable source into the portable, offline HTML distribution."""
from pathlib import Path
import base64
import re
import json
import hashlib

ROOT = Path(__file__).resolve().parent

def verify_payloads():
    expected = json.loads((ROOT / 'asset-hashes.json').read_text())
    js = (ROOT / 'app.js').read_text()
    css = (ROOT / 'app.css').read_text()
    artwork = json.loads(re.search(r'const PG_ASSETS = (\{[^\n]+\});', js)[1])
    actual = {k: hashlib.sha256(v.encode()).hexdigest() for k, v in artwork.items()}
    if actual != expected['artwork']:
        raise ValueError('Encoded artwork differs from reviewed asset hashes; review the intended changes before updating asset-hashes.json.')
    pattern = r'data:[A-Za-z0-9/+.-]+;base64,[A-Za-z0-9+/=]+'
    actual_css = [hashlib.sha256(v.encode()).hexdigest() for v in re.findall(pattern, css)]
    if actual_css != expected['cssPayloads']:
        raise ValueError('Encoded font/pattern data differs from reviewed asset hashes.')

def build():
    verify_payloads()
    html = (ROOT / 'shell.html').read_text()
    for element, filename in [('pg-css', 'app.css'), ('pg-js', 'app.js')]:
        encoded = base64.b64encode((ROOT / filename).read_bytes()).decode('ascii')
        encoded = '\n'.join(encoded[i:i+100] for i in range(0, len(encoded), 100))
        html, count = re.subn(r'(<script[^>]*id="' + element + r'"[^>]*>).*?(</script>)', lambda m: m[1] + '\n' + encoded + '\n' + m[2], html, flags=re.S)
        if count != 1:
            raise ValueError('Missing or duplicate bundle block: ' + element)
    destination = ROOT.parent / 'Puzzle-Garden-v54.html'
    destination.write_text(html)
    print(destination)

if __name__ == '__main__':
    build()
