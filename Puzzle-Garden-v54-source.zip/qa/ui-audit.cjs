const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
(async()=>{const b=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,args:['--no-sandbox']});const errors=[],results=[],OUT=process.env.PG_QA_OUTPUT;
const ids=['hop','echopro','wither','balance','gradient','drift','criticalsum','ravel','golf','rollcall'];
for(const [width,height]of [[320,568],[390,844],[768,1024],[1440,1000]])for(const theme of ['light','dark']){
 const p=await b.newPage({viewport:{width,height},reducedMotion:'reduce'});p.on('pageerror',e=>errors.push(e.message));await p.goto(process.env.PG_QA_URL);await p.evaluate(theme=>UI.setTheme(theme),theme);
 for(const id of ids){await p.evaluate(id=>UI.go('#/play/'+id+'/2026-10-24'),id);await p.waitForFunction(id=>UI.puzzleReady(id,'2026-10-24'),id);await p.evaluate(()=>UI.closePanel());await p.evaluate(()=>document.fonts.ready);
 const state=await p.evaluate(({id,width})=>{
 const r=e=>e.getBoundingClientRect();const issues=[];const visible=e=>r(e).width>0&&r(e).height>0;
 for(const el of document.querySelectorAll('#fit .btn,#fit .gr47-word,#fit .tile:not(.ghost):not(.slot),#fit .cs-tile,#fit .cs-token')){
  const s=getComputedStyle(el);if(s.backgroundImage.includes('url('))issues.push('raster skin on '+el.className);if(s.backgroundColor==='rgba(0, 0, 0, 0)')issues.push('transparent control '+el.className);
 }
 for(const status of document.querySelectorAll('#fit .status'))if(/·\s*·/.test(status.textContent))issues.push('duplicate timer separator');
 for(const tile of document.querySelectorAll('#fit .tile:has(>.g)')){
  const glyph=tile.querySelector(':scope>.g');if(!visible(tile))continue;for(const meta of tile.querySelectorAll(':scope>.tl,:scope>.tr,:scope>.v')){if(!visible(meta))continue;const a=r(glyph),m=r(meta),t=r(tile);if(Math.min(a.right,m.right)-Math.max(a.left,m.left)>1&&Math.min(a.bottom,m.bottom)-Math.max(a.top,m.top)>1)issues.push('letter/metadata overlap');if(m.left<t.left+1||m.right>t.right-1||m.bottom>t.bottom-1)issues.push('metadata outside inset');}
  const metas=[...tile.querySelectorAll(':scope>.tl,:scope>.tr,:scope>.v')].filter(visible);for(let i=0;i<metas.length;i++)for(let j=i+1;j<metas.length;j++){const a=r(metas[i]),c=r(metas[j]);if(Math.min(a.right,c.right)-Math.max(a.left,c.left)>1&&Math.min(a.bottom,c.bottom)-Math.max(a.top,c.top)>1)issues.push('metadata collision')}
 }
 if(id==='ravel'&&width===390){const stage=r(document.querySelector('#stage'));for(const card of document.querySelectorAll('.po-stack .top'))if(r(card).bottom>stage.bottom+1)issues.push('third cascade row below phone viewport')}
 if(id==='rollcall'){
  for(const el of document.querySelectorAll('.rc-die,.rc-pick:not(.demo)')){const face=el.querySelector('.die-face');const color=['moss','sky','clay'].find(c=>el.classList.contains('c-'+c));if(!face||!face.classList.contains('die-'+color))issues.push('die body/selector mismatch')}
  for(const el of document.querySelectorAll('.rc-k'))if(r(el).width>48||r(el).height>48)issues.push('oversized direction button');
 }
 if(id==='hop'){const perks=document.querySelector('.hp-perks');if(width===390&&getComputedStyle(perks).display!=='grid')issues.push('legend did not use readable grid');for(const badge of document.querySelectorAll('.hp-uses'))if(badge.getAttribute('transform')!=='translate(30 -27)')issues.push('counter still at lily notch')}
 if(id==='echopro')for(const el of document.querySelectorAll('.ec-piece'))if(getComputedStyle(el).backgroundImage!=='none')issues.push('track seam background');
 if(id==='criticalsum')for(const el of document.querySelectorAll('.cs-token>small')){const a=r(el),p=r(el.parentElement);if(a.left<p.left+3||a.top<p.top+2)issues.push('slot label touches frame')}
 if(id==='drift')for(const el of document.querySelectorAll('.dt-gt')){const s=el.querySelector('.dt-sym');if(s){const a=r(s),c=r(el);if(a.left<c.left||a.right>c.right||a.top<c.top||a.bottom>c.bottom)issues.push('cropped wrap symbol')}}
 return {id,issues:[...new Set(issues)]};
 },{id,width});results.push({width,height,theme,...state});await p.screenshot({path:path.join(OUT,`audit-${width}-${theme}-${id}.png`)});
 }
 await p.close();
}
// Stage an actual word to test the CTA and the three-field metadata state.
const p=await b.newPage({viewport:{width:390,height:844},reducedMotion:'reduce'});p.on('pageerror',e=>errors.push(e.message));await p.goto(process.env.PG_QA_URL);await p.evaluate(()=>UI.setTheme('dark'));await p.evaluate(()=>UI.go('#/play/wither/2026-10-24'));await p.waitForFunction(()=>UI.puzzleReady('wither','2026-10-24'));await p.evaluate(()=>UI.closePanel());
const word=await p.evaluate(()=>{const s=UI.peekPlay('wither','2026-10-24').state,p=UI.puzzle('wither','2026-10-24'),avail=WG.witherAvailable(s,p);let best=null;for(const w of WORD_LIST){if(w.length<4||w.length>7)continue;const idx=[],used=new Set();for(const L of w){const id=avail.find(i=>p.tiles[i]===L&&!used.has(i));if(id==null)break;idx.push(id);used.add(id)}if(idx.length!==w.length)continue;const o=WG.witherPlay(s,p,idx);if(!o.state)continue;const losses=o.lost.map(i=>p.tiles[i]);const duplicates=new Set(losses).size<losses.length;best={w,duplicates};if(duplicates)break}if(!best)throw Error('No legal preview word');return best});
for(const L of word.w)await p.locator('[data-act="wi-add"][data-l="'+L+'"]').click();await p.screenshot({path:path.join(OUT,'audit-wither-active.png')});const active=await p.evaluate(()=>({caption:document.querySelector('.board>.caption')?.textContent,ctaImage:getComputedStyle(document.querySelector('[data-act="wi-play"]')).backgroundImage,ctaText:document.querySelector('[data-act="wi-play"]').textContent}));assert(!active.ctaImage.includes('url('));if(word.duplicates)assert(active.caption.includes('×'));results.push({id:'wither-active',word,...active,issues:[]});
fs.writeFileSync(path.join(OUT,'ui-audit-results.json'),JSON.stringify({results,errors},null,2));console.log(JSON.stringify({checks:results.length,errors,issues:results.filter(r=>r.issues.length)},null,2));await b.close();if(errors.length||results.some(r=>r.issues.length))process.exitCode=1})().catch(e=>{console.error(e);process.exitCode=1});
