const OUT=process.env.PG_QA_OUTPUT;
const {chromium}=require('playwright');
const fs=require('fs'); const path=require('path');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||undefined,headless:true,args:['--no-sandbox']});
 const results=[];const errors=[];
 for(const [width,height] of [[390,844],[768,1024],[1440,1000],[320,568]]){
 const context=await browser.newContext({viewport:{width,height},reducedMotion:'reduce'});
 const page=await context.newPage();page.on('pageerror',e=>errors.push({width,url:page.url(),error:e.message}));
 await page.goto(process.env.PG_QA_URL);await page.waitForTimeout(2300);
 const games=await page.evaluate(()=>WG.GAMES.map(g=>({id:g.id,name:g.name})));
 for(const g of [{id:'home',name:'Home'},...games]){
 if(g.id!=='home')await page.evaluate(id=>{UI.go('#/play/'+id+'/2026-10-24')},g.id);
 if(g.id!=='home')await page.waitForFunction(id=>UI.puzzleReady(id,'2026-10-24'),g.id,{timeout:20000});
 await page.waitForTimeout(100);
 await page.evaluate(()=>{if(document.querySelector('#panel').open)document.querySelector('#panel').close()});
 await page.waitForTimeout(50);
 const data=await page.evaluate(()=>{
 const rect=e=>{const r=e.getBoundingClientRect();return {x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height),bottom:Math.round(r.bottom),right:Math.round(r.right)}};
 const stage=document.querySelector('#stage'),fit=document.querySelector('#fit'),board=fit?.querySelector('.board');
 const outside=[...document.querySelectorAll('#fit button,#fit .card,#fit .tile,#fit .bq')].filter(e=>{const r=e.getBoundingClientRect();return r.width>0&&(r.right>innerWidth+2||r.left < -2)}).slice(0,12).map(e=>({class:e.className,text:e.textContent.slice(0,40),...rect(e)}));
 return {title:document.title,stage:stage&&{...rect(stage),scrollHeight:stage.scrollHeight,clientHeight:stage.clientHeight,overflow:getComputedStyle(stage).overflowY},fit:fit&&rect(fit),board:board&&rect(board),outside,cards:document.querySelectorAll('.bq').length,brokenImages:[...document.images].filter(i=>!i.complete||!i.naturalWidth).length,failed:document.querySelector('#app').textContent.includes('could not load'),guide:document.querySelector('.desktop-guide')&&rect(document.querySelector('.desktop-guide')),duplicateIds:[...document.querySelectorAll('[id]')].map(e=>e.id).filter((id,i,a)=>a.indexOf(id)!==i)};
 });results.push({width,height,...g,...data});
 if([390,1440].includes(width))await page.screenshot({path:`${OUT}/${process.env.PREFIX||'before'}-${width}-${g.id}.png`});
 }
 await context.close();
 }
 fs.writeFileSync(`${OUT}/${process.env.PREFIX||'before'}-results.json`,JSON.stringify({results,errors},null,2));
 console.log(JSON.stringify({screens:results.length,errors,issues:results.filter(r=>r.failed||r.outside.length||r.brokenImages||r.duplicateIds.length)},null,2));await browser.close();if(errors.length||results.length!==104||results.some(r=>r.failed||r.outside.length||r.brokenImages||r.duplicateIds.length||(r.id!=='home'&&!r.board)))process.exitCode=1;
})().catch(e=>{console.error(e);process.exit(1)});
