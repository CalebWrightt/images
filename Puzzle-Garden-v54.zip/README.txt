Puzzle Garden v54

1. Extract this ZIP completely.
2. Open Puzzle-Garden-v54.html in a web browser.

The game works offline. Use Settings to export a progress backup before changing browser or file version.

Check & Flip has a fixed square board. Word Balance words sit on its pans.
New Rulebreaker games start with an empty grid and 16 pieces in hand.
Old saved mosaics keep their rules and offer a link to the new placement game.

The requested Google Drive pattern pack was blocked from download. This version uses subtle existing bundled patterns instead. See the release notes for details and verification.
