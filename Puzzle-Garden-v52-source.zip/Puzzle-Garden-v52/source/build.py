"""Repack editable source into the portable, offline HTML distribution."""
from pathlib import Path
import base64
import re

ROOT = Path(__file__).resolve().parent

def build():
    html = (ROOT / 'shell.html').read_text()
    for element, filename in [('pg-css', 'app.css'), ('pg-js', 'app.js')]:
        encoded = base64.b64encode((ROOT / filename).read_bytes()).decode('ascii')
        encoded = '\n'.join(encoded[i:i+100] for i in range(0, len(encoded), 100))
        html, count = re.subn(r'(<script[^>]*id="' + element + r'"[^>]*>).*?(</script>)', lambda m: m[1] + '\n' + encoded + '\n' + m[2], html, flags=re.S)
        if count != 1:
            raise ValueError('Missing or duplicate bundle block: ' + element)
    destination = ROOT.parent / 'Puzzle-Garden-v52.html'
    destination.write_text(html)
    print(destination)

if __name__ == '__main__':
    build()
